﻿namespace Nop.Plugin.Misc.CountingSequence.Domain
{
    /// <summary>
    /// Represents a rack level type enum
    /// </summary>
    public enum RackLevelType
    {
        /// <summary>
        ///  Top
        /// </summary>
        Top = 10,

        /// <summary>
        ///  Second
        /// </summary>
        Second = 20,

        /// <summary>
        /// Middle
        /// </summary>
        Middle = 30,

        /// <summary>
        ///  Forth
        /// </summary>
        Forth = 40,

        /// <summary>
        /// Bottom
        /// </summary>
        Bottom = 50,
    }
}
