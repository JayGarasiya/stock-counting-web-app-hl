﻿using Microsoft.AspNetCore.Mvc;
using Nop.Web.Framework.Components;

namespace Nop.Plugin.Misc.CountingSequence.Components
{
    public class CountingSequenceQrButtonViewComponent : NopViewComponent
    {
        public async Task<IViewComponentResult> InvokeAsync(string widgetZone, object additionalData)
        {
            return View("~/Plugins/Misc.CountingSequence/Views/CountingSequenceQrButton.cshtml", additionalData);

        }
    }
}
