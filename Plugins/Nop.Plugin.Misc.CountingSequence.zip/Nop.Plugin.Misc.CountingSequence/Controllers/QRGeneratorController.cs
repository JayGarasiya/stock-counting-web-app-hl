﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core.Domain.Catalog;
using Nop.Services.Catalog;
using Nop.Services.Media;
using Nop.Services.Shipping;
using QRCoder;
using System.Text;

namespace Nop.Plugin.Misc.CountingSequence.Controllers
{
    [Area("Admin")]
    public class QRGeneratorController : Controller
    {
        protected readonly IProductService _productService;
        protected readonly IPictureService _pictureService;
        protected readonly ICategoryService _categoryService;
        protected readonly ISpecificationAttributeService _specificationAttributeService;
        protected readonly IWarehouseService _warehouseService;

        public QRGeneratorController(
            IProductService productService,
            IPictureService pictureService,
            ICategoryService categoryService,
            ISpecificationAttributeService specificationAttributeService,
            IWarehouseService warehouseService)
        {
            _productService = productService;
            _pictureService = pictureService;
            _categoryService = categoryService;
            _specificationAttributeService = specificationAttributeService;
            _warehouseService = warehouseService;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Generate(int productId)
        {
            var product = await _productService.GetProductByIdAsync(productId);
            if (product == null)
                return Json(false);

            var categories = await _categoryService.GetProductCategoriesByProductIdAsync(productId);
            var warehouseInventory = await _productService.GetAllProductWarehouseInventoryRecordsAsync(productId);

            var sb = new StringBuilder();

            sb.AppendLine($"Product Name: {product.Name}");
            sb.AppendLine($"SKU: {product.Sku}");

            sb.AppendLine("Categories:");
            foreach (var cat in categories)
            {
                var category = await _categoryService.GetCategoryByIdAsync(cat.CategoryId);
                sb.AppendLine($"- {category?.Name}");
            }

            var specs = await _specificationAttributeService
                .GetProductSpecificationAttributesAsync(productId);

            foreach (var spec in specs)
            {
                var option = await _specificationAttributeService
                    .GetSpecificationAttributeOptionByIdAsync(spec.SpecificationAttributeOptionId);

                if (option != null)
                {
                    var specificationAttribute = await _specificationAttributeService
                        .GetSpecificationAttributeByIdAsync(option.SpecificationAttributeId);

                    sb.AppendLine($"{specificationAttribute?.Name}: {option.Name}");
                }
            }
            sb.AppendLine("Quantity per cases: " + product.OrderMaximumQuantity);

            foreach (var wh in warehouseInventory)
            {
                var warehouse = await _warehouseService.GetWarehouseByIdAsync(wh.WarehouseId);

                sb.AppendLine($"Warehouse: {warehouse?.Name}");
                sb.AppendLine($"Warehouse Quantity: {wh.StockQuantity}");
            }

            string qrText = sb.ToString();

            using (QRCodeGenerator qrGenerator = new QRCodeGenerator())
            {
                QRCodeData qrCodeData = qrGenerator.CreateQrCode(qrText, QRCodeGenerator.ECCLevel.Q);
                PngByteQRCode qrCode = new PngByteQRCode(qrCodeData);
                byte[] qrCodeImage = qrCode.GetGraphic(20);

                var picture = await _pictureService.InsertPictureAsync(
                    qrCodeImage,
                    "image/png",
                    $"product_{productId}_qr"
                );

                var productPicture = new ProductPicture
                {
                    ProductId = productId,
                    PictureId = picture.Id,
                    DisplayOrder = 0
                };

                await _productService.InsertProductPictureAsync(productPicture);
            }

            return Json(true);
        }
    }
}
