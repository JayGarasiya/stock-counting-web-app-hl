﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Misc.CountingSequence.Models.Rack
{
    /// <summary>
    /// Represents an add product to rack model
    /// </summary>
    public partial record AddProductToRackModel : BaseSearchModel
    {
        #region Ctor

        public AddProductToRackModel()
        {
            SelectedProductIds = new List<int>();
        }

        #endregion

        #region Properties

        public IList<int> SelectedProductIds { get; set; }

        public int RackId { get; set; }

        public int LevelId { get; set; }

        #endregion

    }
}
